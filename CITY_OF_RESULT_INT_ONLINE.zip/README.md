# CITY OF RESULT IN'T — Online Website Package

This package is designed for Cloudflare Pages + Pages Functions, D1, and R2.

## What it provides
- Public CITY OF RESULT IN'T website
- Your supplied logo
- Public administrator messages
- Visitor question form
- Admin-only dashboard
- Admin-only picture uploads
- Online storage for messages/questions/pictures
- Server-side admin authentication
- WhatsApp group button

## Important security note
The administrator PIN is NOT written into the website source. Set it as a Cloudflare secret named `ADMIN_PIN`.
Do not put the PIN in `wrangler.toml`, GitHub, or the public website.

## Deploy
1. Create a Cloudflare account.
2. Create a D1 database named `city-of-result-db`.
3. Run `schema.sql` against that D1 database.
4. Create an R2 bucket named `city-of-result-images`.
5. Put the D1 database ID into `wrangler.toml`.
6. Set the admin PIN as a secret:
   `npx wrangler pages secret put ADMIN_PIN`
7. Deploy this project to Cloudflare Pages with the `public` folder as the static output and the `functions` folder included.
8. Cloudflare will give you a `*.pages.dev` address.

For the easiest Git-based route, put this project in a GitHub repository and connect that repository to Cloudflare Pages.

## Very important
The old local-only version could not synchronize messages between phones. This version uses a real online database and image storage, so visitors can see content you post online.

Do not publish private credentials in the repository.
