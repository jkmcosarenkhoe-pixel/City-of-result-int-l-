async function isAdmin(request,env){
 const c=request.headers.get("Cookie")||""; const m=c.match(/(?:^|;\\s*)city_admin=([^;]+)/); if(!m)return false;
 const d=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(m[1]));
 const h=[...new Uint8Array(d)].map(x=>x.toString(16).padStart(2,"0")).join("");
 return !!(await env.DB.prepare("SELECT token_hash FROM sessions WHERE token_hash=? AND expires_at>CAST(strftime('%s','now') AS INTEGER)").bind(h).first());
}

export async function onRequestPost({request,env}) {
 if(!await isAdmin(request,env))return Response.json({error:"Unauthorized"},{status:401});
 const form=await request.formData(); const file=form.get("image"); const caption=String(form.get("caption")||"").slice(0,500);
 if(!(file instanceof File))return Response.json({error:"No image"} ,{status:400});
 if(file.size>8*1024*1024 || !file.type.startsWith("image/"))return Response.json({error:"Image must be under 8MB"} ,{status:400});
 const key=crypto.randomUUID()+"-"+file.name.replace(/[^a-zA-Z0-9._-]/g,"_");
 await env.IMAGES.put(key,file.stream(),{httpMetadata:{contentType:file.type}});
 await env.DB.prepare("INSERT INTO pictures(object_key,caption) VALUES(?,?)").bind(key,caption).run();
 return Response.json({ok:true});
}