async function isAdmin(request,env){
 const c=request.headers.get("Cookie")||""; const m=c.match(/(?:^|;\\s*)city_admin=([^;]+)/); if(!m)return false;
 const d=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(m[1]));
 const h=[...new Uint8Array(d)].map(x=>x.toString(16).padStart(2,"0")).join("");
 return !!(await env.DB.prepare("SELECT token_hash FROM sessions WHERE token_hash=? AND expires_at>CAST(strftime('%s','now') AS INTEGER)").bind(h).first());
}

export async function onRequestGet({request,env}) {
 if(!await isAdmin(request,env))return Response.json({error:"Unauthorized"},{status:401});
 const q=await env.DB.prepare("SELECT id,name,text,created_at FROM questions ORDER BY id DESC LIMIT 200").all();
 return Response.json({questions:q.results});
}