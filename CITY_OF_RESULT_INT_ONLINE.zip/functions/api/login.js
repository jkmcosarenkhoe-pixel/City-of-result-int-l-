export async function onRequestPost({request, env}) {
  const {pin} = await request.json().catch(()=>({}));
  if (!pin || pin !== env.ADMIN_PIN) return Response.json({error:"Invalid login"}, {status:401});
  const token = crypto.randomUUID() + "-" + crypto.randomUUID();
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(token));
  const hash = [...new Uint8Array(digest)].map(x=>x.toString(16).padStart(2,"0")).join("");
  const expires = Math.floor(Date.now()/1000) + 60*60*24*7;
  await env.DB.prepare("INSERT INTO sessions(token_hash,expires_at) VALUES(?,?)").bind(hash,expires).run();
  return new Response(JSON.stringify({ok:true}), {headers:{"Content-Type":"application/json","Set-Cookie":`city_admin=${token}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=604800`}});
}