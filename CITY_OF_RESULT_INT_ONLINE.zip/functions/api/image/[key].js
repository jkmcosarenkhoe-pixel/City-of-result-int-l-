export async function onRequestGet({params,env}) {
 const key=params.key;
 const obj=await env.IMAGES.get(key);
 if(!obj)return new Response("Not found",{status:404});
 const headers=new Headers(); obj.writeHttpMetadata(headers); headers.set("Cache-Control","public,max-age=86400");
 return new Response(obj.body,{headers});
}