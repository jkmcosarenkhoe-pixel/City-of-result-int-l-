export async function onRequestGet({request,env}) {
  const ok = await isAdmin(request,env);
  if(!ok) return Response.json({error:"Unauthorized"},{status:401});
  return Response.json({ok:true});
}
export async function isAdmin(request,env){
  const cookie=request.headers.get("Cookie")||"";
  const m=cookie.match(/(?:^|;\s*)city_admin=([^;]+)/);
  if(!m) return false;
  const digest=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(m[1]));
  const hash=[...new Uint8Array(digest)].map(x=>x.toString(16).padStart(2,"0")).join("");
  const row=await env.DB.prepare("SELECT token_hash FROM sessions WHERE token_hash=? AND expires_at>CAST(strftime('%s','now') AS INTEGER)").bind(hash).first();
  return !!row;
}