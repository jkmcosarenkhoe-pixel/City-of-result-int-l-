export async function onRequestPost({request,env}) {
 const {name,text}=await request.json().catch(()=>({}));
 if(!text || String(text).length>3000)return Response.json({error:"Invalid question"},{status:400});
 await env.DB.prepare("INSERT INTO questions(name,text) VALUES(?,?)").bind(String(name||"Visitor").slice(0,100),String(text).slice(0,3000)).run();
 return Response.json({ok:true});
}