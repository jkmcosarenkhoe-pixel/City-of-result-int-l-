export async function onRequestPost({env}) {
  return new Response(JSON.stringify({ok:true}), {headers:{"Content-Type":"application/json","Set-Cookie":"city_admin=; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=0"}});
}