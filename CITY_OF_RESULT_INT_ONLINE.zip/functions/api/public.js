export async function onRequestGet({env}) {
 const messages=await env.DB.prepare("SELECT id,text,created_at FROM messages ORDER BY id DESC LIMIT 100").all();
 const rows=await env.DB.prepare("SELECT id,object_key,caption,created_at FROM pictures ORDER BY id DESC LIMIT 50").all();
 const pictures=rows.results.map(x=>({...x,url:"/api/image/"+x.object_key}));
 return Response.json({messages:messages.results,pictures});
}